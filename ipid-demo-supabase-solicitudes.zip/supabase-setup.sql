-- IPID · Registro y login con Supabase
-- Ejecutar completo en: Supabase > SQL Editor > New query > Run

-- 1) Tabla de perfiles (un RUC por usuario)
create table if not exists public.perfiles (
  id uuid primary key references auth.users(id) on delete cascade,
  ruc text not null unique,
  email text not null,
  created_at timestamptz not null default now()
);

alter table public.perfiles enable row level security;

drop policy if exists "perfil propio: lectura" on public.perfiles;
create policy "perfil propio: lectura"
  on public.perfiles for select
  to authenticated
  using (auth.uid() = id);

-- 2) Al crearse un usuario en Auth, se crea su perfil con el RUC enviado en el registro
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.perfiles (id, ruc, email)
  values (new.id, new.raw_user_meta_data->>'ruc', new.email);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 3) Funciones para el login por RUC (el login de Supabase usa correo)
create or replace function public.email_por_ruc(p_ruc text)
returns text
language sql
security definer
stable
set search_path = public
as $$
  select email from public.perfiles where ruc = p_ruc limit 1;
$$;

create or replace function public.ruc_existe(p_ruc text)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (select 1 from public.perfiles where ruc = p_ruc);
$$;

revoke all on function public.email_por_ruc(text) from public;
revoke all on function public.ruc_existe(text) from public;
grant execute on function public.email_por_ruc(text) to anon, authenticated;
grant execute on function public.ruc_existe(text) to anon, authenticated;

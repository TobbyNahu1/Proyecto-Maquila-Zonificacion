-- DEMO PÚBLICA: usar exclusivamente datos ficticios.
-- Este acceso permite a cualquier visitante leer, crear y modificar registros.
create table if not exists public.solicitudes_ipid (
 id text primary key,
 codigo text not null,
 tipo text not null check (tipo in ('confirmacion','excepcion')),
 fecha text,
 correo text,
 ruc text,
 razon_social text,
 distrito text,
 distrito_ubicacion text,
 sector text,
 inversion text,
 empleos text,
 producto text,
 ncm text,
 motivo text,
 archivos jsonb not null default '[]'::jsonb,
 estado text not null default 'PENDIENTE',
 created_at timestamptz not null default now()
);
create index if not exists solicitudes_ipid_fecha_idx on public.solicitudes_ipid(created_at desc);
alter table public.solicitudes_ipid enable row level security;
grant select, insert, update on public.solicitudes_ipid to anon, authenticated;
drop policy if exists "demo_select_solicitudes" on public.solicitudes_ipid;
drop policy if exists "demo_insert_solicitudes" on public.solicitudes_ipid;
drop policy if exists "demo_update_solicitudes" on public.solicitudes_ipid;
create policy "demo_select_solicitudes" on public.solicitudes_ipid for select to anon, authenticated using (true);
create policy "demo_insert_solicitudes" on public.solicitudes_ipid for insert to anon, authenticated with check (true);
create policy "demo_update_solicitudes" on public.solicitudes_ipid for update to anon, authenticated using (true) with check (true);

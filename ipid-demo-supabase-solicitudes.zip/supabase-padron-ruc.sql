-- IPID: padrón real: padron_ruc(ruc, nombre, dv, estado).
-- IMPORTANTE: ejecutar en el MISMO proyecto de Supabase que usa el portal.
-- Si ya creaste buscar_ruc con retorno (ruc, razon_social, estado), este script
-- conserva exactamente esa firma. No elimina registros ni modifica políticas RLS.

create or replace function public.buscar_ruc(p_ruc text)
returns table (ruc text, razon_social text, estado text)
language sql
security definer
stable
set search_path = ''
as $$
  select (p.ruc::text || '-' || p.dv::text)::text,
         p.nombre::text,
         p.estado::text
  from public.padron_ruc as p
  where regexp_replace(p_ruc, '[^0-9]', '', 'g') =
        regexp_replace(p.ruc::text || p.dv::text, '[^0-9]', '', 'g')
  limit 1;
$$;

revoke all on function public.buscar_ruc(text) from public;
grant execute on function public.buscar_ruc(text) to anon, authenticated;

-- Prueba desde SQL Editor:
select * from public.buscar_ruc('80099501-5');
-- Debe devolver el RUC, razón social y estado ACTIVO.
-- Si SQL Editor funciona pero el navegador no, inspeccioná la petición
-- /rest/v1/rpc/buscar_ruc en DevTools > Network (403/404/400).
